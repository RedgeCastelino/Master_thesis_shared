#!/usr/bin/env python
import numpy as np
import rospy
import math
from ClassKF import KF , rotatedata


# import all necessary ROS messages
from object_list.msg import ObjectList, ObjectsList
from osi3_bridge.msg import GroundTruthMovingObjects, TrafficUpdateMovingObject
global count1
global count99
count1 = 0
count = 0
import message_filters
from ClassSens import Sens , Ego
KFlist=[]
countlist=[]
count99 = 0
skip = 0
#print('hi')
counter =0
rotateinfo=[]
egocount=0
egoveh = Ego()
for i in range(1000):
    a = KF()
    b=rotatedata()
    KFlist.append(a)
    rotateinfo.append(b)
    #countlist.append(0)
sens = Sens()

# import function
from rotate import rotate

# import class


def sensor_rotate():
    # Node initialization
    rospy.init_node('sensor2ego', anonymous=False)  # Start node
    rate = rospy.Rate(25)  # Define the node frequency 1hz
    #print ("sensor_rotate WORKS ")
    # Subscriber the data in callback function
    #vel_vector = np.array([[1],[2],[3]])
    #x = (vel_vector.transpose()).dot(vel_vector)
    #print (x)


    #global egoveh
    #rospy.Subscriber("ego_data", TrafficUpdateMovingObject, callback2) #rospy.get_param("egodataname") for reference changed

    ego_data = message_filters.Subscriber('/ego_data', TrafficUpdateMovingObject)
    objs_list = message_filters.Subscriber('/sensor0/objs_list', ObjectsList)
    ts = message_filters.ApproximateTimeSynchronizer([ego_data, objs_list], 20, 20)
    #ts = message_filters.TimeSynchronizer([ego_data, objs_list], 10)
    ts.registerCallback(callback)





    #rospy.Subscriber("objs_list", ObjectsList, callback)

    rospy.spin()



    

def callback(ego_data,objs_list):
    global egoveh
    global egocount
    global time
    # print('EGOO')
    #print('callback ego')
    #print(ego_data.object.velocity.x)

    egoveh.vel.x = ego_data.object.velocity.x
    egoveh.vel.y = ego_data.object.velocity.y
    egoveh.acc.x = ego_data.object.acceleration.x
    egoveh.acc.y = ego_data.object.acceleration.y
    if egocount == 0 :
        egoveh.neworientation = ego_data.object.orientation.yaw
        egocount+=1
    else:
        egoveh.oldorientation =  egoveh.neworientation
        egoveh.neworientation=ego_data.object.orientation.yaw
       # egoveh.oldyaw = egoveh.newyaw
        egoveh.newyaw = egoveh.oldorientation-egoveh.neworientation
        if time == 0 :
            p = 0.1
            egoveh.yawrate = (egoveh.newyaw ) / p
        else:
            egoveh.yawrate = (egoveh.newyaw)/time
    #print(egoveh.newyaw,egoveh.oldyaw)
    #print(egoveh.neworientation-egoveh.oldorientation)
    

    
    #print(objs_list)

    pub=rospy.Publisher('obj_list_egoframe', ObjectsList, queue_size=10,latch=True)

    new_objs_list = vector_rotate(objs_list)
    print(new_objs_list)
    if rospy.get_param("sensortype") != 5:
        filtered_objs_list = kalman(new_objs_list)
        pub.publish(filtered_objs_list)
    else:
        pub.publish(new_objs_list)
        print(new_objs_list)
    #print("callback objlist")

    #print("END")
    #print(filtered_objs_list)
    #filtered_objs_list =


def vector_rotate(objs_list):
    global egoveh
    global new
    global old
    global time
    global count1
    global count
    global old_objs
    if count1 ==0:
        new = float(str(objs_list.header.stamp.nsecs))
        time = 0.01
        count1 +=1

    else:
        #print ('time is ', objs_list.header.stamp.nsecs)
        #print(objs_list)
        old = new
        new = float(str(objs_list.header.stamp.nsecs))
        time = float(str((new-old)))/1000000000 #nsecs to secs
        #print ('old time',old)
        #print ('new time',new)
        #print ('diff is ',1/time)
    #print ('count is',count)
    sens = Sens()

    #print (sens.rot.yaw,objs_list.obj_list[0].geometric.yaw)
    if rospy.get_param("sensortype") == 1:

        #FOR RADAR
        if count == 0:
            for i,a in enumerate(objs_list.obj_list): # need to change this for loop

                objs_list.header.frame_id = "EGOframe"
             #Change the sensor position origin from sensor to ego

                [a.geometric.x,a.geometric.y] = rotate(a.geometric.x, a.geometric.y, -sens.rot.yaw)
                [a.geometric.vx,a.geometric.vy] = rotate(a.geometric.vx, a.geometric.vy, -sens.rot.yaw)
                a.geometric.x = a.geometric.x + sens.pos.x
                a.geometric.y = a.geometric.y + sens.pos.y

                vel_vector = np.array([[a.geometric.vx],[a.geometric.vy],[0]])
                omega = np.array([[0],[0],[a.geometric.yawrate]])
                vel_derivative = np.array([[0],[0],[0]])
                accl_vector = vel_derivative + np.cross(omega,vel_vector ,axis=0)
                a.geometric.ax = accl_vector[0][0] + egoveh.acc.x
                a.geometric.ay = accl_vector[1][0] + egoveh.acc.y

                #print(time)



        else:
            for i,a in enumerate(objs_list.obj_list):

                objs_list.header.frame_id = "EGOframe"
             #Change the sensor position origin from sensor to ego
                [a.geometric.x,a.geometric.y] = rotate(a.geometric.x, a.geometric.y, -sens.rot.yaw)
                [a.geometric.vx,a.geometric.vy] = rotate(a.geometric.vx, a.geometric.vy, -sens.rot.yaw)
                a.geometric.x = a.geometric.x + sens.pos.x
                a.geometric.y = a.geometric.y + sens.pos.y
                vel_vector = np.array([[a.geometric.vx],[a.geometric.vy],[0]])
                old_vel = np.array([[old_objs.obj_list[i].geometric.vx],[old_objs.obj_list[i].geometric.vy],[0]])
                omega = np.array([[0],[0],[a.geometric.yawrate]])
                vel_derivative = (vel_vector-old_vel)/time
                accl_vector = vel_derivative + np.cross(omega,vel_vector ,axis=0)
                a.geometric.ax = accl_vector[0][0] + egoveh.acc.x
                a.geometric.ay = accl_vector[1][0] + egoveh.acc.y

    elif rospy.get_param("sensortype") == 5:
        #for ideal sensor

        for i, a in enumerate(objs_list.obj_list):  # need to change this for loop

            objs_list.header.frame_id = "EGOframe"
            # Change the sensor position origin from sensor to ego



            [a.geometric.x, a.geometric.y] = rotate(a.geometric.x, a.geometric.y, sens.rot.yaw)
            [a.geometric.vx, a.geometric.vy] = rotate(a.geometric.vx, a.geometric.vy, sens.rot.yaw)
            #a.geometric.vx -= egoveh.vel.x
            #a.geometric.vy -= egoveh.vel.y
            [a.geometric.ax, a.geometric.ay] = rotate(a.geometric.ax, a.geometric.ay, -sens.rot.yaw)
            #a.geometric.ax -= egoveh.acc.x
            #a.geometric.y -= egoveh.acc.y
            a.geometric.x = a.geometric.x + sens.pos.x
            a.geometric.y = a.geometric.y + sens.pos.y
            return objs_list





    else:
        # FOR CAMERA/Lidar
        #print('this')
        if count == 0:
            for i,a in enumerate(objs_list.obj_list): # need to change this for loop

                objs_list.header.frame_id = "EGOframe"
             #Change the sensor position origin from sensor to egosss

                [a.geometric.x,a.geometric.y] = rotate(a.geometric.x, a.geometric.y, -sens.rot.yaw)
                [a.geometric.vx,a.geometric.vy] = rotate(a.geometric.vx, a.geometric.vy, -sens.rot.yaw)
                a.geometric.x = a.geometric.x + sens.pos.x
                a.geometric.y = a.geometric.y + sens.pos.y


                omega = np.array([[0],[0],[egoveh.yawrate]])
                pos_vector = np.array([[a.geometric.x],[a.geometric.y],[0]])
                old_pos = np.array([[0],[0],[0]])
                pos_derivative = (pos_vector-old_pos)/time
                vel_vector = pos_derivative + np.cross(omega,pos_vector ,axis=0)
                vel_derivative = np.array([[0],[0],[0]])
                a.geometric.vx = vel_vector[0][0] + egoveh.vel.x
                a.geometric.vy = vel_vector[1][0] + egoveh.vel.y

                accl_vector = vel_derivative + np.cross(omega,vel_vector ,axis=0)
                a.geometric.ax = accl_vector[0][0] + egoveh.acc.x
                a.geometric.ay = accl_vector[1][0] + egoveh.acc.y


                #print(accl_vector)



        else:
            for i,a in enumerate(objs_list.obj_list):

                x = rotateinfo[a.obj_id]
                print('ID',a.obj_id)
                #print(a.geometric.y)
                #print(x.posx)
                objs_list.header.frame_id = "EGOframe"
             #Change the sensor position origin from sensor to ego
                #print("before rot y is",a.geometric.y)
                [a.geometric.x,a.geometric.y] = rotate(a.geometric.x, a.geometric.y, sens.rot.yaw)
                #print("new y is", a.geometric.y)
                a.geometric.x = a.geometric.x + sens.pos.x
                a.geometric.y = a.geometric.y + sens.pos.y
                objs_list.obj_list[i].geometric.x = a.geometric.x
                objs_list.obj_list[i].geometric.y = a.geometric.y
                omega = np.array([[0],[0],[egoveh.yawrate]])
                om = [0,0,-egoveh.yawrate]
                pos_vector = np.array([[a.geometric.x],[a.geometric.y],[0]])
                pvec = [a.geometric.x,a.geometric.y,0]
#               try:
#                    old_pos = np.array([[old_objs.obj_list[i].geometric.x],[old_objs.obj_list[i].geometric.y],[0]])
 #                   pos_derivative = (pos_vector-old_pos)/time
  #                  print('pos_vec is', pos_vec)
   #                 print('oldpos_vec is', old_pos)
    #                print('pos_der is',pos_derivative)
     #               vel_vector = pos_derivative + np.cross(omega,pos_vector ,axis=0)
      #              a.geometric.vx = vel_vector[0][0]+ egoveh.vel.x
       #             a.geometric.vy = vel_vector[1][0]+ egoveh.vel.y
#
 #                   old_vel = np.array([[old_objs.obj_list[i].geometric.vx],[old_objs.obj_list[i].geometric.vy],[0]])
#
 #                   vel_derivative = (vel_vector-old_vel)/time
  #                  accl_vector = vel_derivative + np.cross(omega,vel_vector ,axis=0)
   #                 a.geometric.ax = accl_vector[0][0]+ egoveh.acc.x
    #                a.geometric.ay = accl_vector[1][0]+ egoveh.acc.y
     #           except :
      #              print('hi')
       #             vel_vector = pos_derivative + np.cross(omega,pos_vector ,axis=0)
        #            vel_derivative = np.array([[0],[0],[0]])
         #           a.geometric.vx = vel_vector[0][0] + egoveh.vel.x
          #          a.geometric.vy = vel_vector[1][0] + egoveh.vel.y
#
 #                   accl_vector = vel_derivative + np.cross(omega,vel_vector ,axis=0)
  #                  a.geometric.ax = accl_vector[0][0] + egoveh.acc.x
   #                 a.geometric.ay = accl_vector[1][0] + egoveh.acc.y
    #                print(accl_vector)
                old_pos = np.array([[x.posx], [x.posy], [0]])
                #old_pos = rotate(old_pos[0,0],old_pos[1,0],-egoveh.newyaw)
                #pos_derivative = (pos_vector - old_pos) / time
                #print('2nd element is ',old_pos[1,0])
                #print(type(pvec))
                #pos_diff = np.array([[(pos_vector[0, 0] - old_pos[0])/time ], [(pos_vector[1, 0] - old_pos[1])/time], [0]])
                #print(pos_diff)
                pos_derivative = np.array([[(pos_vector[0,0]-old_pos[0])/time], [(pos_vector[1,0]-old_pos[1])/time], [0]])
                #vel_vector= pos_derivative + np.cross(om, pvec)
                vel_vector = pos_derivative + np.cross(omega, pos_vector, axis=0)
                #print('ID is', a.obj_id)
               # print('yaw is',egoveh.newyaw*180/3.14,egoveh.oldyaw*180/3.14)
                #print('pos_vec is', pos_vector)
                #print('pos_vec is', np.sqrt(np.square(old_pos[1,0])+np.square(old_pos[0,0])), np.sqrt(np.square(a.geometric.x)+np.square(a.geometric.y)))
                #print('vely in kph is', pos_derivative[1] * 3.6)
                #print('vel in kph is', np.sqrt(np.square(pos_derivative[0])+np.square(pos_derivative[1]))*3.6)
                #print(a.geometric.x,a.geometric.y)

                #print('with yaw vel in kph is', np.sqrt(np.square(vel_vector[0,0]) + np.square(vel_vector[1,0])) * 3.6)
                #print (pos_derivative)
                print('vel is', vel_vector)
                #print(time)
                #print(pos_vector[0,0]-x.posx,pos_vector[1,0]-x.posy)
                #print("pos der is", pos_derivative)
                #print(pos_vector[1,0],x.posy,time)
                #vel_vector = pos_derivative + np.cross(omega, pos_vector, axis=0)
                vel_derivative = np.array([[vel_vector[0, 0] - x.velx], [vel_vector[1, 0] - x.vely], [0]]) / time
                a.geometric.vx = vel_vector[0][0] + egoveh.vel.x
                a.geometric.vy = vel_vector[1][0] + egoveh.vel.y
                accl_vector = vel_derivative + np.cross(omega, vel_vector, axis=0)

                objs_list.obj_list[i].geometric.ax = vel_derivative[0,0]
                objs_list.obj_list[i].geometric.ay = accl_vector[1,0]

                #need to change the following with accurate yawrate

                objs_list.obj_list[i].geometric.vx = pos_derivative[0,0]
                #print (objs_list.obj_list[i].geometric.vx,pos_derivative)
                objs_list.obj_list[i].geometric.vy = pos_derivative[1,0]

                #print (objs_list.obj_list[i].geometric.vx,pos_derivative[0,0])

                rotateinfo[a.obj_id].posx=pos_vector[0,0]
                rotateinfo[a.obj_id].posy=pos_vector[1,0]
                rotateinfo[a.obj_id].velx=pos_derivative[0,0]
                rotateinfo[a.obj_id].vely= pos_derivative[1,0]
                rotateinfo[a.obj_id].accx = vel_derivative[0, 0]
                rotateinfo[a.obj_id].accy = vel_derivative[1, 0]
                #print('acc in g is', vel_derivative /9.8)
                #print('oldpos_vec is', rotateinfo[a.obj_id].posx, pos_vector[0, 0])
                #print(a.obj_id,vel_derivative[0,0])

    count+=1
    old_objs=objs_list
    #print(objs_list)
    #print("YAW",len(objs_list.obj_list))
    #print (sens.rot.yaw,objs_list.obj_list[0].geometric.yaw)
    #print(objs_list)

    #print ("THIS IS")
    #print (count)
    #count+=1
    return objs_list

def kalman(objs_list):
    global KF
    global count99
    global counter
    global oldtime
    global newtime
    global skip


    #print (objs_list)

    for i,a in enumerate(objs_list.obj_list):
        if skip <= 4:
            skip+=1
            break


       # print ('unfiltered',a.geometric.vx)
        x = KFlist[a.obj_id]
        #print(x)
        #if count99 == 0:
         #   x.xnn = np.array([[a.geometric.x], [a.geometric.vx], [a.geometric.ax], [a.geometric.y],[a.geometric.vy],[a.geometric.ay]])
          #  print(a)
           # print('xnn intial is ',x.xnn)
        if x.track == 0:

            x.track = 1
            x.newtime= float(str(objs_list.header.stamp))
            x.oldtime=  x.newtime
            t = 0.1


            x.a = np.array([[1,t,t*t/2,0,0,0],[0,1,t,0,0,0],[0,0,1,0,0,0],[0,0,0,1,t,t*t/2],[0,0,0,0,1,t],[0,0,0,0,0,1]])
            #x.xnn = np.array([[a.geometric.x], [a.geometric.vx], [a.geometric.ax], [a.geometric.y],[a.geometric.vy],[a.geometric.ay]])
            x.g = np.array([[t*t*t/6,0],[t*t/2,0],[t,0],[0,t*t*t/6],[0,t*t/2],[0,t]])

        else:
            x.newtime = float(str(objs_list.header.stamp))
            t = x.newtime-x.oldtime
            if t >= 1.5:
                x=KF()
                x.track = 1
                x.newtime= float(str(objs_list.header.stamp))

                t = 0.1
                x.a = np.array([[1,t,t*t/2,0,0,0],[0,1,t,0,0,0],[0,0,1,0,0,0],[0,0,0,1,t,t*t/2],[0,0,0,0,1,t],[0,0,0,0,0,1]])

                x.g = np.array([[t*t*t/6,0],[t*t/2,0],[t,0],[0,t*t*t/6],[0,t*t/2],[0,t]])
                #KF[a.obj_id]=x

            x.oldtime=  x.newtime
        #print(x.a)
        #print(x.xnn)
        x.yn = np.array([[a.geometric.x], [a.geometric.y]]) # column vector
        #print('a is' , x.a)
        #Kalman equations
        x.xn_nm1 =x.a.dot(x.xnn) #column vector
        #print('xnm is',x.xn_nm1)
        #print('check1',x.xn_nm1[1])
        #print(type(x.g))
        #if count99 <= 1:
         #   print('unfiltered', a.geometric)
          #  print('OBJ ID IS', a.obj_id)
        #print('xnn is',x.xnn)
            #print('xnm is', x.xn_nm1)
            #print('y is', x.yn)
            #print('GAMMA is', x.gamma_n)

        x.pn_nm1 = (x.a.dot(x.pnn)).dot(x.a.transpose()) +(x.g.dot(x.c_s)).dot(x.g.transpose())
        x.gamma_n = x.yn -x.c.dot(x.xn_nm1)
        x.s_n = (x.c.dot(x.pn_nm1)).dot(x.c.transpose()) + x.c_m
        x.k_n = (x.pn_nm1.dot(x.c.transpose())).dot(np.linalg.inv(x.s_n))
        #print('y is',x.yn)
        #print('diff is is',x.c.dot(x.xn_nm1))
        #print('GAMMA is', x.gamma_n)
        #print('c is', x.c)
        x.xnn = x.xn_nm1 + x.k_n.dot(x.gamma_n)

        #if count99 <= 1:
            #print('filtered is ', x.xnn)


        #print('xnn',x.xnn)
        I = np.zeros((6,6),int)
        np.fill_diagonal(I,1)
        x.pnn = (I - x.k_n.dot(x.c)).dot(x.pn_nm1)
        #print('pnn',x.pn_nm1)
        KFlist[a.obj_id]=x
        a.geometric.x = x.xnn[0]
        a.geometric.vx = x.xnn[1]
        a.geometric.ax = x.xnn[2]
        a.geometric.y = x.xnn[3]
        a.geometric.vy = x.xnn[4]
        a.geometric.ay = x.xnn[5]
        #print(x.pnn)
        a.covariance = x.pnn.flatten()
        #print('filtered is' ,a.geometric.vy)
        #if count99 == 0:
         #   print('ID is', a.obj_id)
          #  print('vel is',x.xnn[1])
    #pub = rospy.Publisher('afterKF', ObjectsList, queue_size=10)
    #pub.publish(objs_list)
    #print(objs_list)
    #print(count99)
    count99 += 1
    #print(x.track)
    return(objs_list)


if __name__ == '__main__':
    sensor_rotate()
